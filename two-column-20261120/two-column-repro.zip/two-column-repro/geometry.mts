import fs from 'node:fs';import path from 'node:path';import {pathToFileURL} from 'node:url';
const repo=process.env.PAPILOT_REPO||process.cwd(),base=process.env.PAPILOT_REPRO_DIR||path.dirname(new URL(import.meta.url).pathname);
const {PdfDocument}=await import(pathToFileURL(path.join(repo,'engine/src/render/pdf.ts')).href);
function glyphs(file:string){const d=new PdfDocument(file),chars=[];for(let p=0;p<d.length;p++)for(const line of d.page(p).lines)for(const c of line.chars)if(!c.appearance.includes('[1,0,0]'))chars.push({page:p,text:c.text,rect:c.rect});d.close();return chars;}
const results=[];
for(const location of ['left','right'])for(const variant of ['plain','rich'])for(const side of ['before','after']){
 const a=glyphs(path.join(base,'cases',`visible-${location}-${variant}`,side+'.pdf')),b=glyphs(path.join(base,'cases',`hidden-${location}-${variant}`,side+'.pdf'));
 const sameText=a.length===b.length&&a.every((c,i)=>c.page===b[i].page&&c.text===b[i].text);const maxCoordinateDelta=sameText?Math.max(...a.flatMap((c,i)=>c.rect.map((x,j)=>Math.abs(x-b[i].rect[j])))):null;
 results.push({location,variant,side,glyphs:[a.length,b.length],sameText,maxCoordinateDelta});
}
fs.writeFileSync(path.join(base,'geometry.json'),JSON.stringify(results,null,2));console.log(JSON.stringify(results));
const report=JSON.parse(fs.readFileSync(path.join(base,'report.json'),'utf8'));
console.log(JSON.stringify(report.map(r=>({name:r.name,oldHeight:r.oldHeight,newHeight:r.newHeight,strips:r.oldStrips.map(s=>({left:s.left,width:s.width,height:s.height,page:s.page,first:s.text.slice(0,50)}))})),null,2));
