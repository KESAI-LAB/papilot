import fs from 'node:fs';import path from 'node:path';import {pathToFileURL} from 'node:url';import {execFileSync} from 'node:child_process';
const repo=process.env.PAPILOT_REPO||process.cwd(),base=process.env.PAPILOT_REPRO_DIR||path.dirname(new URL(import.meta.url).pathname);
process.env.PAPILOT_DATA=path.join(base,'data');
const load=(name:string)=>import(pathToFileURL(path.join(repo,name)).href);
const {App,createServer}=await load('engine/src/server.ts');const {PdfDocument}=await load('engine/src/render/pdf.ts');const {Build}=await load('engine/src/render/locate.ts');const {compareDocuments}=await load('engine/src/render/effects.ts');
const {chromium}=await load('engine/node_modules/playwright/index.mjs');
const input=process.env.PAPILOT_FIXTURE||path.join(path.dirname(new URL(import.meta.url).pathname),'baseline.tex');
const source=fs.readFileSync(input,'utf8');fs.writeFileSync(path.join(base,'baseline.tex'),source);
const positions=[{name:'left',needle:'The storage component keeps an immutable copy of every completed measurement.',prefix:'The storage component'},{name:'right',needle:'The recovery procedure starts from the last complete record rather than from an intermediate file.',prefix:'The recovery procedure'}];
const browser=await chromium.launch({channel:process.env.PAPILOT_BROWSER_CHANNEL||'chrome',headless:true});const report=[];
try{
for(const rulers of ['visible','hidden']){
 const root=path.join(base,'paper-'+rulers);fs.mkdirSync(root,{recursive:true});
 const before=rulers==='visible'?source:source.replace('\\settopmatter',String.raw`\makeatletter\renewcommand\ACM@linecountL{}\renewcommand\ACM@linecountR{}\makeatother`+'\n\\settopmatter');
 fs.writeFileSync(path.join(root,'main.tex'),before);const git=(...args:string[])=>execFileSync('git',['-C',root,...args],{stdio:'pipe'}).toString().trim();git('init','-q');git('config','user.name','Synthetic Reproduction');git('config','user.email','repro@localhost');git('config','commit.gpgsign','false');git('add','.');git('commit','-qm','Create ACM two-column control');
 const app=new App(root);await app.ready;const server=createServer(app);app.url=await server.listen({host:'127.0.0.1',port:0});
 const api=async(route:string,body?:unknown)=>{const r=await fetch(app.url+route,body===undefined?undefined:{method:'POST',headers:{'content-type':'application/json','x-review-token':app.csrf},body:JSON.stringify(body)});const v=await r.json();if(!r.ok)throw Error(JSON.stringify(v));return v;};
 try{
  for(const position of positions)for(const variant of ['plain','rich']){
   const name=`${rulers}-${position.name}-${variant}`,folder=path.join(base,'cases',name);fs.mkdirSync(folder,{recursive:true});
   const addition=variant==='rich'?String.raw`We additionally preserve the \emph{original observation order} when a delayed worker publishes its result.`:'We additionally preserve the original observation order when a delayed worker publishes its result.';
   const after=before.replace(position.needle,position.needle+' '+addition);if(after===before)throw Error('Missing fixture sentence');
   const task=await api('/api/tasks',{name,title:`ACM ${position.name} column, ${rulers} rulers, ${variant} edit`,files:['main.tex'],deferred:true});fs.writeFileSync(path.join(task.worktree,'main.tex'),after);
   fs.writeFileSync(path.join(folder,'before.tex'),before);fs.writeFileSync(path.join(folder,'after.tex'),after);
   const job=await api(`/api/tasks/${name}/publish`,{indirect:false});console.log('Publishing '+name);let status;
   for(let i=0;i<600;i++){status=await api('/api/jobs/'+job.job);if(['done','failed'].includes(status.status))break;await new Promise(r=>setTimeout(r,500));}
   if(status.status!=='done')throw Error(JSON.stringify(status));
   const detail=await api(`/api/tasks/${name}/rounds/1`);if(detail.rendering)throw Error('Incomplete rendering '+JSON.stringify(detail.rendering));
   fs.writeFileSync(path.join(folder,'round.json'),JSON.stringify(detail,null,2));
   const builds=detail.builds.map(key=>JSON.parse(fs.readFileSync(path.join(app.state,'cache','builds',key,'result.json'),'utf8')));
   const oldInfo=builds.find(info=>fs.readFileSync(path.join(info.root,'main.tex'),'utf8')===before),newInfo=builds.find(info=>fs.readFileSync(path.join(info.root,'main.tex'),'utf8')===after);if(!oldInfo||!newInfo)throw Error('Build sources not found '+JSON.stringify(detail.builds));
   const oldBuild=new Build(oldInfo,'main.tex',''),newBuild=new Build(newInfo,'main.tex','');
   const location=(build:any)=>{for(let page=0;page<build.document.length;page++){const current=build.document.page(page),line=current.lines.find(l=>l.text.startsWith(position.prefix));if(line)return {page:page+1,column:current.column(line.rect),rect:line.rect,twoColumns:current.twoColumns};}return null;};
   const changedLocation=[location(oldBuild),location(newBuild)];
   if(changedLocation.some(p=>!p||!p.twoColumns||p.column!==(position.name==='left'?0:1)))throw Error('Target is not in expected column '+JSON.stringify(changedLocation));
   const comparison=compareDocuments(oldBuild,newBuild);
   const effects=comparison.changes.map(e=>({kind:e.kind||'text',old:e.old?comparison.old.tokens.slice(...e.old).map(t=>t.text).join(' '):null,new:e.new?comparison.new.tokens.slice(...e.new).map(t=>t.text).join(' '):null}));
   const blocks=[...detail.sections.flatMap(s=>s.blocks.filter(b=>b.kind==='change')),...detail.loose];
   const strips=(side:string)=>blocks.flatMap(b=>b[side]).map(s=>({src:s.src,left:s.left,top:s.top,page:s.page,width:s.width,height:s.height,text:(s.text||[]).map(l=>l.text).join(' ')}));
   const oldStrips=strips('before'),newStrips=strips('after');
   const numbers=(build:any)=>Array.from({length:build.document.length},(_,i)=>build.document.page(i).lines.filter(l=>/^\d+$/.test(l.text.trim())&&l.chars.some(c=>String(c.appearance).includes('[1,0,0]'))).flatMap(l=>l.chars.map(c=>({page:i,text:c.text,rect:c.rect})))).flat();
   const oldNumbers=numbers(oldBuild),newNumbers=numbers(newBuild);
   const result={name,rulers,position:position.name,variant,changedLocation,pages:[oldBuild.document.length,newBuild.document.length],units:detail.units.map(u=>({id:u.id,old:u.old_text,new:u.new_text,kind:u.kind,visual:u.visual})),effects,oldStrips,newStrips,oldHeight:oldStrips.reduce((n,s)=>n+s.height,0),newHeight:newStrips.reduce((n,s)=>n+s.height,0),warnings:detail.warnings||[],errors:[...oldInfo.errors||[],...newInfo.errors||[]],rulerGlyphCount:[oldNumbers.length,newNumbers.length],rulersUnchanged:JSON.stringify(oldNumbers)===JSON.stringify(newNumbers),builds:[oldInfo.key,newInfo.key]};
   if(result.units.length!==1)throw Error('Expected one edit, got '+result.units.length);
   fs.copyFileSync(oldInfo.pdf,path.join(folder,'before.pdf'));fs.copyFileSync(newInfo.pdf,path.join(folder,'after.pdf'));fs.cpSync(path.join(app.state,'rounds',name,'001'),path.join(folder,'rendered'),{recursive:true});
   oldBuild.close();newBuild.close();
   const page=await browser.newPage({viewport:{width:1440,height:1000},locale:'en-US',colorScheme:'light'});const errors=[];
   page.on('pageerror',e=>errors.push(e.message));
   await page.route(app.url+'/**',async route=>{const u=new URL(route.request().url());if(u.pathname==='/')return route.fulfill({contentType:'text/html',body:fs.readFileSync(path.join(base,'engine-web','index.html'),'utf8')});if(u.pathname.startsWith('/assets/'))return route.fulfill({path:path.join(base,'engine-web',u.pathname),contentType:u.pathname.endsWith('.js')?'text/javascript':u.pathname.endsWith('.css')?'text/css':'application/octet-stream'});return route.continue();});
   await page.goto(app.url+'/?task='+name);
   await page.locator('.change[data-stop]').first().waitFor({timeout:30000});
   await page.locator('.change img').first().waitFor({timeout:30000});
   await page.evaluate(async()=>{await Promise.all([...document.querySelectorAll('.change img')].map(i=>(i as HTMLImageElement).decode().catch(()=>undefined)));const paper=document.querySelector('#paper')!,change=document.querySelector('.change')!;paper.scrollTop+=change.getBoundingClientRect().top-paper.getBoundingClientRect().top-45;});
   await page.screenshot({path:path.join(folder,'review-desktop.png'),fullPage:true});
   const ui=await page.locator('.change[data-stop]').evaluateAll(elements=>elements.map(e=>({units:e.getAttribute('data-units'),height:e.getBoundingClientRect().height,text:e.textContent?.slice(0,200)})));
   result.ui={changes:ui,errors};if(errors.length)throw Error(JSON.stringify(errors));await page.close();
   fs.writeFileSync(path.join(folder,'metrics.json'),JSON.stringify(result,null,2));report.push(result);fs.writeFileSync(path.join(base,'report.json'),JSON.stringify(report,null,2));
   console.log(JSON.stringify({name,pages:result.pages,oldHeight:result.oldHeight,newHeight:result.newHeight,columns:changedLocation.map(p=>p.column),blocks:blocks.length,warnings:result.warnings.length,effects:result.effects}));
  }
 }finally{await server.close();await app.close();}
}
}finally{await browser.close();}
console.log('Verified '+report.length+' cases at '+base);
