ACM two-column diff verification — 2026-11-20

Issue: https://github.com/PapilotAI/papilot/issues/266
Verified locally; no application code changes or fix applied.

Result
Both physical columns reproduce oversized before strips when adding a sentence containing \emph while ACM review rulers are visible. Plain-text edits and the same rich-text edits with only rulers hidden remain local.
All eight cases completed through the real review-engine HTTP task/publish/round endpoints and the freshly built review UI. The API responses and rendered assets were not mocked. No live AI agent or Electron window was exercised.

Environment
Repository HEAD: da9a36c334bf127afa70d5ee4b4edfa6432fbd8c
Checked remote main: aa3893ffd369617c304b471ea38ad78075fc9373
No difference between those commits in engine/src/render, engine/src/core/publish.ts, or engine/src/core/review.ts.
macOS arm64; Node.js 22.22.0; TeX Live 2025; acmart 2.12; Chrome headless desktop viewport 1440 x 1000.

Measurements
Heights below are summed PDF strip heights in points, not a physical page height.
Case                         Before      After
visible-left-plain              10.22      21.18
visible-left-rich             1227.78     131.60
visible-right-plain             10.22      21.18
visible-right-rich            1227.78      82.07
hidden-left-plain               10.22      21.18
hidden-left-rich                46.40      57.36
hidden-right-plain              10.22      21.18
hidden-right-rich               59.70      69.50

Controls and limits
- Every case is a single source insertion; semantic comparison finds an insertion without deletion.
- Each source remains two pages. Changed paragraphs are confirmed in the requested physical column before and after.
- All 588 red ruler glyphs retain identical text, page and coordinates before/after in visible-ruler cases.
- Hiding rulers retains review=true and overrides only ACM@linecountL / ACM@linecountR.
- Visible-versus-hidden PDFs have identical non-ruler text and page assignments; maximum coordinate difference is 0.0020752 pt.
- Published rounds have no compilation errors or warnings; UI screenshots have no browser page errors.
- Four existing column-related tests passed; 152 non-matching tests were skipped. This was a focused verification, not the full test suite.
- This fixture demonstrates the failure condition; it does not establish that all two-column documents or all LaTeX commands are affected.

Evidence
cases/<case>/review-desktop.png: real built review UI screenshot.
cases/<case>/before.tex, after.tex, before.pdf, after.pdf: synthetic source and compiled output.
cases/<case>/round.json: published round response; rendered/: actual generated review artifacts.
cases/<case>/metrics.json and report.json: measured PDF strips, source units, semantic changes and UI measurements.
geometry.json: visible/hidden ruler body-glyph comparison.
baseline-two-column-page.png: full two-column baseline PDF page.
All manuscript text was created for this reproduction. No user screenshots or private manuscript content are included.

Reproduce (fresh disposable output directory required)
Prerequisites: this repository with root/engine dependencies installed, Node.js 22.22+, TeX Live with acmart and the PDF tooling required by the engine, Chrome or an installed Playwright Chromium.
Run with the selected Node.js and TeX binaries on PATH:

papilot_repo=/path/to/papilot
evidence=/path/to/two-column-repro
verification_dir=$(mktemp -d)
cd "$papilot_repo/engine"
node node_modules/vite/bin/vite.js build --outDir "$verification_dir/engine-web"
cd "$papilot_repo"
PAPILOT_REPO="$papilot_repo" PAPILOT_REPRO_DIR="$verification_dir" PAPILOT_FIXTURE="$evidence/baseline.tex" node --import tsx "$evidence/verify.mts"
PAPILOT_REPO="$papilot_repo" PAPILOT_REPRO_DIR="$verification_dir" node --import tsx "$evidence/geometry.mts"

Set PAPILOT_BROWSER_CHANNEL=chromium for Playwright Chromium; default is installed Chrome.
Inspect the report and screenshots in verification_dir. The harness closes its browser and servers. Delete only this disposable directory when finished.

Targeted existing tests
cd "$papilot_repo/engine"
node node_modules/vitest/vitest.mjs run tests/ts/align.test.ts tests/ts/tricky-pdf.test.ts --testNamePattern 'two columns|column|spanning'

Public copy: local paths in logs have been generalized, and the fixture default in verify.mts now resolves to the included baseline.tex. Experiment logic and evidence are otherwise unchanged.
